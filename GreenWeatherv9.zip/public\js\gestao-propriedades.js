"use strict";

const formPropriedade = document.getElementById("form-propriedade");
const listaPropriedades = document.getElementById("lista-propriedades");
const mensagemPropriedade = document.getElementById("mensagem-propriedade");
const botaoPropriedade = document.getElementById("salvar-propriedade");

function mostrarMensagem(texto, tipo = "") {
  mensagemPropriedade.textContent = texto;
  mensagemPropriedade.className = `management-message${tipo ? ` ${tipo}` : ""}`;
}

async function carregarPropriedades() {
  const { propriedades } = await GW.requisitar("GET", "/api/propriedades");
  listaPropriedades.replaceChildren();
  for (const propriedade of propriedades) {
    const linha = document.createElement("tr");
    for (const valor of [
      propriedade.nome, propriedade.municipio, propriedade.uf,
      Number(propriedade.areaHa).toLocaleString("pt-BR", { maximumFractionDigits: 2 })
    ]) {
      const celula = document.createElement("td");
      celula.textContent = valor;
      linha.appendChild(celula);
    }
    listaPropriedades.appendChild(linha);
  }
  if (!propriedades.length) {
    listaPropriedades.innerHTML = '<tr><td colspan="4" class="empty">Nenhuma propriedade cadastrada.</td></tr>';
  }
}

formPropriedade.addEventListener("submit", async event => {
  event.preventDefault();
  const dados = new FormData(formPropriedade);
  const nome = String(dados.get("nome") || "").trim();
  const municipio = String(dados.get("municipio") || "").trim();
  const uf = String(dados.get("uf") || "");
  const areaHa = Number(dados.get("areaHa"));
  if (!nome || !municipio || !uf || !Number.isFinite(areaHa) || areaHa <= 0) {
    mostrarMensagem("Preencha todos os campos com valores válidos.", "error");
    return;
  }

  botaoPropriedade.disabled = true;
  mostrarMensagem("Salvando propriedade…");
  try {
    await GW.requisitar("POST", "/api/propriedades", { nome, municipio, uf, areaHa });
    formPropriedade.reset();
    mostrarMensagem("Propriedade cadastrada.", "success");
    await carregarPropriedades();
  } catch (erro) {
    mostrarMensagem(erro.message, "error");
  } finally {
    botaoPropriedade.disabled = false;
  }
});

carregarPropriedades().catch(erro => {
  listaPropriedades.innerHTML = `<tr><td colspan="4" class="empty">${erro.message}</td></tr>`;
});
