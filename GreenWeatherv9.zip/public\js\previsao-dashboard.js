(function(){
  const lista = document.getElementById("previsao-lista");
  const f1 = valor => Number(valor).toFixed(1).replace(".", ",");

  function mostrarVazio(texto){
    const mensagem = document.createElement("p");
    mensagem.className = "previsao-vazio";
    mensagem.textContent = texto;
    lista.replaceChildren(mensagem);
  }

  function desenhar(previsoes){
    if (!previsoes.length) {
      mostrarVazio("Nenhuma tendência de saída da faixa ideal foi identificada com as leituras disponíveis.");
      return;
    }

    const itens = previsoes.map(previsao => {
      const item = document.createElement("article");
      item.className = "previsao-item";
      const cabecalho = document.createElement("strong");
      cabecalho.textContent = `${previsao.sensor} · ${previsao.grandeza}`;
      const detalhe = document.createElement("span");
      detalhe.textContent = `Tendência de ${previsao.tendencia}: ${f1(previsao.valorAtual)} ${previsao.unidade} agora; pode atingir ${previsao.limite} ${previsao.unidade} em ${previsao.horas < 1 ? "menos de 1 hora" : `cerca de ${f1(previsao.horas)} horas`}.`;
      const horario = document.createElement("small");
      horario.textContent = `Estimativa para ${new Date(previsao.previstoEm).toLocaleString("pt-BR")}`;
      item.append(cabecalho, detalhe, horario);
      return item;
    });
    lista.replaceChildren(...itens);
  }

  async function carregar(){
    try {
      const resultado = await GW.requisitar("GET", "/api/previsao");
      desenhar(resultado.previsoes);
    } catch (erro) {
      mostrarVazio(`Não foi possível gerar a estimativa: ${erro.message}`);
    }
  }

  carregar();
  setInterval(carregar, 5 * 60 * 1000);
})();
