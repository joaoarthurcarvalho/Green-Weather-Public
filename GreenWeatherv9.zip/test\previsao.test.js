"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const preverCondicoes = require("../previsao");

function leiturasDeTemperatura(agora, valores, intervalo = 30 * 60 * 1000) {
  return valores.map((t, i) => ({
    s: "sensor-01", ts: agora - (valores.length - 1 - i) * intervalo, t, u: 65
  }));
}

test("estima cruzamento de limite dentro do horizonte", () => {
  const agora = Date.now();
  const resultado = preverCondicoes(leiturasDeTemperatura(agora, [24, 25, 26, 27, 28]), agora);

  assert.equal(resultado.previsoes.length, 1);
  assert.equal(resultado.previsoes[0].grandeza, "temperatura");
  assert.equal(resultado.previsoes[0].tendencia, "alta");
  assert.equal(resultado.previsoes[0].limite, 30);
  assert.equal(resultado.previsoes[0].horas, 1);
});

test("não prevê com poucos dados, leitura antiga ou variável já fora da faixa", () => {
  const agora = Date.now();
  const poucas = leiturasDeTemperatura(agora, [24, 26, 28, 29]);
  const antigas = leiturasDeTemperatura(agora - 20 * 60 * 1000, [24, 25, 26, 27, 28]);
  const fora = leiturasDeTemperatura(agora, [32, 33, 34, 35, 36]);

  assert.deepEqual(preverCondicoes(poucas, agora).previsoes, []);
  assert.deepEqual(preverCondicoes(antigas, agora).previsoes, []);
  assert.deepEqual(preverCondicoes(fora, agora).previsoes, []);
});

test("não extrapola quando o limite está além das próximas três horas", () => {
  const agora = Date.now();
  const leituras = leiturasDeTemperatura(agora, [21, 21.5, 22, 22.5, 23]);

  assert.deepEqual(preverCondicoes(leituras, agora).previsoes, []);
});
