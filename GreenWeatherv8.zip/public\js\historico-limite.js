(function(){
  const LIMITE = 15;

  const tbody  = document.getElementById("tabela");
  const rodape = document.getElementById("rodape");
  const barra  = document.createElement("div");
  const botao  = document.createElement("button");
  barra.style.cssText = "display:flex;justify-content:center;margin-top:12px";
  barra.hidden = true;
  botao.type = "button";
  botao.className = "btn btn-ghost";
  barra.appendChild(botao);
  tbody.closest(".card").querySelector(".table-wrap").insertAdjacentElement("afterend", barra);

  let expandido = false;

  function aplicar(){
    const linhas = [...tbody.rows].filter(tr => !tr.querySelector(".empty"));   // ignora a linha "nenhuma leitura"
    const total = linhas.length;
    linhas.forEach((tr, i) => { tr.style.display = !expandido && i >= LIMITE ? "none" : ""; });
    if (total <= LIMITE){ barra.hidden = true; return; }
    barra.hidden = false;
    botao.textContent = expandido ? "Mostrar menos" : `Mostrar mais (${total - LIMITE} restantes)`;
    rodape.textContent = expandido
      ? `Exibindo todas as ${total} leituras do período`
      : `Exibindo ${LIMITE} de ${total} leituras do período`;
  }

  botao.addEventListener("click", () => { expandido = !expandido; aplicar(); });

  new MutationObserver(() => { expandido = false; aplicar(); }).observe(tbody, { childList: true });
  aplicar();
})();
