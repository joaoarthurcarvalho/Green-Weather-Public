# Green Weather

Sistema web para monitoramento de temperatura e umidade, com cadastro de usuários, sensores, histórico e alarmes.

## Estrutura atual

```text
GreenWeather/
├── server.js                  # servidor HTTP, API, autenticação e arquivos estáticos
├── alarmes.js                 # regras e persistência de alarmes
├── package.json               # comandos e versão mínima do Node.js
├── scripts/                   # ferramentas de simulação e demonstração
│   ├── simulador.js
│   └── exemplo.js
├── data/                      # dados locais persistidos pelo sistema
│   ├── alarmes.json
│   ├── config.json            # chave local dos sensores
│   ├── leituras.jsonl
│   └── usuarios.json
└── public/
    ├── html/                  # páginas do sistema
    ├── css/                   # estilos compartilhados e por tela
    ├── js/                    # integração com API e interação da interface
    └── assets/                # logotipo e recursos estáticos
```

As páginas são servidas em `/html/<pagina>.html`; CSS, JavaScript e imagens ficam
nas pastas `/css/`, `/js/` e `/assets/`. Para compatibilidade, `/` abre o login,
e os atalhos `/<pagina>.html` redirecionam para as páginas correspondentes em
`/html/` (inclusive funcionários e propriedades). O atalho legado
`/cadastro.html` continua direcionando ao login.

## O que já existe

- Aplicação web servida diretamente pelo Node.js, sem dependências externas.
- Login; senhas armazenadas com `scrypt`, sessões por cookie e funções de conta.
- Cadastro, ativação, desativação e exclusão de contas de funcionários e engenheiros pelo superadministrador, com matrícula automática. Contas de superadmin não podem ser alteradas ou excluídas pela tela de funcionários; desativar uma conta encerra suas sessões e bloqueia novos logins.
- Cadastro de propriedades rurais por engenheiros agrônomos.
- Recepção de leituras de sensores com chave de API, validação básica e deduplicação.
- Resumo de sensores e consulta de histórico agrupado por intervalo.
- Alarmes ambientais e de sensor offline, com consulta por período e categoria.
- Interface em português com painel, histórico, configurações de conta e preferências visuais.
- Simuladores para envio contínuo, geração de histórico e criação de dados demonstrativos.

## Requisitos

- Node.js 18 ou superior.
- Um navegador moderno.
- Sensores capazes de enviar JSON para a API (ou o simulador incluído).

## Executar localmente

```powershell
npm start
```

Abra `http://localhost:3000`. O primeiro superadministrador é criado por variáveis de ambiente:

```powershell
$env:SUPERADMIN_NAME = "Nome do administrador"
$env:SUPERADMIN_EMAIL = "admin@exemplo.com"
$env:SUPERADMIN_PASSWORD = "defina-uma-senha-segura"
npm start
```

Configure essas variáveis na máquina/serviço de hospedagem, nunca dentro dos arquivos do projeto. Se já existir um superadmin, a inicialização não cria outro. Para um banco de dados de usuários existente sem superadmin, configure as três variáveis para provisionar o administrador inicial.

Para desenvolvimento com reinício automático:

```powershell
npm run dev
```

Com o servidor ativo, use outro terminal para simular leituras:

```powershell
npm run simular
npm run historico
node scripts/simulador.js falha
```

`node scripts/exemplo.js` grava dados de demonstração nos arquivos locais de leituras e alarmes. Faça uma cópia dos dados antes de executá-lo em uma instalação em uso.

## Configuração

O servidor aceita as variáveis de ambiente `PORT`, `FUSO`, `SENSOR_API_KEY`, `HTTPS`, `ALARME_OFFLINE_MIN`, `DATA_DIR` e as três variáveis de bootstrap do superadmin. Sem `SENSOR_API_KEY`, uma chave local é criada em `data/config.json`; mantenha esse arquivo privado. Para desenvolvimento, o simulador também aceita `API` para definir a URL do servidor.

Em produção, configure HTTPS em um proxy reverso confiável e defina `HTTPS=1` para que o cookie de sessão use `Secure`. O servidor HTTP incluído não configura TLS por conta própria.

## Relatório: necessidades e prioridades

### Prioridade alta — antes de uso público ou produção

1. **Persistência e concorrência:** os dados são arquivos JSON/JSONL carregados em memória. Recomenda-se migrar para SQLite ou PostgreSQL, com migrações e tratamento de concorrência.
2. **Proteção operacional:** configurar HTTPS, backups testados e política de retenção para leituras e alarmes. Os arquivos em `data/` contêm dados operacionais e não devem ser publicados.
3. **Cobertura de testes:** ainda não há testes automatizados para rotas, autenticação, histórico, alarmes ou regras do simulador.
4. **Painel conectado aos dados reais:** `public/html/dashboard.html` ainda contém valores demonstrativos fixos; conectar cartões, tabela e gráfico às APIs é necessário para que o painel represente os sensores instalados.

### Prioridade média

5. **Validação e observabilidade:** adicionar logs estruturados, endpoint de saúde e validações centralizadas de entrada.
6. **Configurações de alarmes:** permitir ajustar limites ambientais e tempos de offline sem editar o código.
7. **Manutenção de dados:** implementar exportação/importação e retenção configurável para o histórico.
8. **Qualidade da interface:** substituir datas demonstrativas fixas por períodos dinâmicos e revisar acessibilidade e estados de carregamento/erro.

## Segurança e dados locais

- `data/config.json`, `data/usuarios.json`, `data/alarmes.json`, `data/leituras.jsonl` e `data/propriedades.json` são arquivos locais de execução e estão excluídos do Git.
- Não armazene senhas ou chaves de sensores em arquivos de exemplo, documentação ou repositórios.
- Se uma chave ou senha real já tiver sido compartilhada, substitua-a antes de colocar o sistema em produção.
