/* =========================================================
   Green Weather — conexão com o backend 
   ========================================================= */
const GW = (() => {
  const K_USUARIO = "gw_usuario";   // só guarda nome/e-mail para exibir; a sessão de verdade está no cookie

  const lerCache = () => { try { return JSON.parse(localStorage.getItem(K_USUARIO)); } catch { return null; } };
  const salvarCache = u => localStorage.setItem(K_USUARIO, JSON.stringify(u));
  const limparCache = () => localStorage.removeItem(K_USUARIO);

  /* Faz uma chamada à API. Se a sessão expirou (401), volta para o login. */
  async function requisitar(metodo, url, corpo, extra = {}) {
    let r;
    try {
      r = await fetch(url, {
        method: metodo, credentials: "same-origin",
        headers: metodo === "GET" ? {} : { "Content-Type": "application/json" },
        body: metodo === "GET" ? undefined : JSON.stringify(corpo || {}),
        ...extra
      });
    } catch {
      throw new Error("Não foi possível falar com o servidor. Ele está ligado?");
    }
    let dados = {};
    try { dados = await r.json(); } catch {}
    if (r.status === 401 && url !== "/api/login") { limparCache(); location.replace("login.html"); }
    if (!r.ok) throw new Error(dados.erro || "Erro inesperado no servidor.");
    return dados;
  }

  function mostrarNome(u) {
    if (!u) return;
    document.querySelectorAll("[data-user-name]").forEach(el => el.textContent = `${u.nome} ${u.sobrenome}`);
  }

  async function cadastrar({ nome, sobrenome, email, senha }) {
    const { usuario } = await requisitar("POST", "/api/cadastro", { nome, sobrenome, email, senha });
    salvarCache(usuario);
  }
  async function entrar(email, senha) {
    const { usuario } = await requisitar("POST", "/api/login", { email, senha });
    salvarCache(usuario);
  }
  function sair() {
    limparCache();
    requisitar("POST", "/api/logout", {}, { keepalive: true }).catch(() => {});   // keepalive: termina mesmo trocando de página
  }
  const usuarioAtual = lerCache;

  async function atualizarSenha(atual, nova) { await requisitar("POST", "/api/me/senha", { atual, nova }); }
  async function atualizarEmail(senha, novoEmail) {
    const { usuario } = await requisitar("POST", "/api/me/email", { senha, novoEmail });
    salvarCache(usuario);
  }
  async function desconectarOutros() {
    const { desconectados } = await requisitar("POST", "/api/me/desconectar-outros");
    return desconectados;
  }

  /* Use no <head> das páginas protegidas */
  function exigirLogin() {
    if (!lerCache()) { location.replace("login.html"); return; }
    // confirma com o servidor em segundo plano (se a sessão expirou, o requisitar() leva ao login)
    requisitar("GET", "/api/me").then(({ usuario }) => { salvarCache(usuario); mostrarNome(usuario); }).catch(() => {});
  }
  
  function redirecionarSeLogado() { if (lerCache()) location.replace("dashboard.html"); }

  document.addEventListener("DOMContentLoaded", () => {
    mostrarNome(lerCache());
    const btn = document.getElementById("sair");
    if (btn) btn.addEventListener("click", e => { e.preventDefault(); sair(); location.href = "login.html"; });
  });

  return { cadastrar, entrar, sair, usuarioAtual, exigirLogin, redirecionarSeLogado,
           atualizarSenha, atualizarEmail, desconectarOutros, requisitar };
})();
