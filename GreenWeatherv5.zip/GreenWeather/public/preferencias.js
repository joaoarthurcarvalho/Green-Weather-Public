/* =========================================================
   Green Weather preferencias do usuario (tema, graficos, alarmes)
   ========================================================= */
const GWPrefs = (() => {
  const CHAVE  = "gw_prefs";
  
  const PADRAO = { tema: "escuro", graficos: true, alarmes: true };

  const ler = () => {
    try { return { ...PADRAO, ...JSON.parse(localStorage.getItem(CHAVE)) }; }
    catch { return { ...PADRAO }; }
  };

  function aplicar(p = ler()){
    const html = document.documentElement;
    html.setAttribute("data-tema", p.tema);
    html.classList.toggle("sem-graficos", !p.graficos);
  }

  function definir(chave, valor){
    const p = ler();
    p[chave] = valor;
    localStorage.setItem(CHAVE, JSON.stringify(p));
    aplicar(p);
  }

  document.write('<link rel="stylesheet" href="tema-claro.css">');
  aplicar();

  return { ler, definir };
})();
