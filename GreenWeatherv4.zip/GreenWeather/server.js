"use strict";
const http   = require("node:http");
const fs     = require("node:fs");
const path   = require("node:path");
const crypto = require("node:crypto");
const { promisify } = require("node:util");
const scrypt = promisify(crypto.scrypt);

/* ---------- Configuração ---------- */
const PORTA       = Number(process.env.PORT) || 3000;
const FUSO        = process.env.FUSO || "America/Recife";   
const HTTPS       = process.env.HTTPS === "1";               
const SESSAO_MS   = 7 * 24 * 3600 * 1000;                   
const ONLINE_MS   = 15 * 60 * 1000;                          
const DIR_DADOS   = path.join(__dirname, "data");
const DIR_PUBLICO = path.join(__dirname, "public");
fs.mkdirSync(DIR_DADOS, { recursive: true });

/* ---------- Chave que os sensores usam para enviar dados ---------- */
const ARQ_CONFIG = path.join(DIR_DADOS, "config.json");
let chaveSensores = process.env.SENSOR_API_KEY || "";
if (!chaveSensores) {
  try { chaveSensores = JSON.parse(fs.readFileSync(ARQ_CONFIG, "utf8")).chaveSensores || ""; } catch {}
  if (!chaveSensores) {
    chaveSensores = "gw_" + crypto.randomBytes(16).toString("hex");
    fs.writeFileSync(ARQ_CONFIG, JSON.stringify({ chaveSensores }, null, 2));
  }
}

/* ---------- Usuários e sessões (arquivo JSON) ---------- */
const ARQ_DB = path.join(DIR_DADOS, "usuarios.json");
let db = { usuarios: [], sessoes: [] };
try { db = { ...db, ...JSON.parse(fs.readFileSync(ARQ_DB, "utf8")) }; } catch {}
function salvarDb() {
  const tmp = ARQ_DB + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, ARQ_DB);                                
}
function limparSessoes() {
  const antes = db.sessoes.length;
  db.sessoes = db.sessoes.filter(s => s.expira > Date.now());
  if (db.sessoes.length !== antes) salvarDb();
}
limparSessoes();
setInterval(limparSessoes, 3600 * 1000).unref();

/* ---------- Leituras dos sensores ---------- */
const ARQ_LEIT = path.join(DIR_DADOS, "leituras.jsonl");
const porDia   = new Map();   
const sensores = new Map();   
const vistos   = new Set();   

const fmtLocal = new Intl.DateTimeFormat("en-CA", {
  timeZone: FUSO, year: "numeric", month: "2-digit", day: "2-digit",
  hour: "2-digit", minute: "2-digit", hourCycle: "h23"
});
function partes(ts) {
  const o = {};
  for (const p of fmtLocal.formatToParts(ts)) o[p.type] = p.value;
  return { d: `${o.year}-${o.month}-${o.day}`, h: `${o.hour}:${o.minute}` };
}
function indexar(l) {
  vistos.add(l.s + "|" + l.ts);
  if (!porDia.has(l.d)) porDia.set(l.d, []);
  porDia.get(l.d).push(l);
  const s = sensores.get(l.s);
  if (!s || l.ts >= s.ts) sensores.set(l.s, { ts: l.ts, t: l.t, u: l.u });
}
if (fs.existsSync(ARQ_LEIT)) {
  for (const linha of fs.readFileSync(ARQ_LEIT, "utf8").split("\n")) {
    if (!linha) continue;
    try { indexar(JSON.parse(linha)); } catch {}
  }
}

/* ---------- Utilidades ---------- */
class ErroHttp extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const sha256    = s => crypto.createHash("sha256").update(s).digest("hex");
const normEmail = e => String(e || "").trim().toLowerCase();
const emailOk   = e => /^\S+@\S+\.\S+$/.test(e) && e.length <= 120;
const textoOk   = (v, max) => typeof v === "string" && v.trim().length > 0 && v.trim().length <= max;
const senhaOk   = s => typeof s === "string" && s.length >= 6 && s.length <= 200;
const publico   = u => ({ nome: u.nome, sobrenome: u.sobrenome, email: u.email });

async function hashSenha(senha) {
  const sal = crypto.randomBytes(16);
  const h = await scrypt(senha, sal, 64);
  return sal.toString("hex") + ":" + h.toString("hex");
}
async function confereSenha(senha, guardado) {
  const [sal, h] = guardado.split(":");
  const calc = await scrypt(senha, Buffer.from(sal, "hex"), 64);
  const orig = Buffer.from(h, "hex");
  return calc.length === orig.length && crypto.timingSafeEqual(calc, orig);
}
const HASH_FALSO = hashSenha("senha-falsa");                 

function enviar(res, status, corpo, cabecalhos = {}) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    ...cabecalhos
  });
  res.end(JSON.stringify(corpo));
}
function lerCorpo(req, limite = 1_000_000) {
  return new Promise((ok, falha) => {
    const blocos = []; let tam = 0, estourou = false;
    req.on("data", c => { tam += c.length; if (tam > limite) estourou = true; else blocos.push(c); });
    req.on("end", () => {
      if (estourou) return falha(new ErroHttp(413, "Corpo da requisição grande demais."));
      if (!blocos.length) return ok({});
      try { ok(JSON.parse(Buffer.concat(blocos).toString("utf8"))); }
      catch { falha(new ErroHttp(400, "JSON inválido.")); }
    });
    req.on("error", falha);
  });
}
function cookies(req) {
  const o = {};
  for (const par of (req.headers.cookie || "").split(";")) {
    const i = par.indexOf("=");
    if (i > 0) { try { o[par.slice(0, i).trim()] = decodeURIComponent(par.slice(i + 1).trim()); } catch {} }
  }
  return o;
}
const cookieSessao = (token, seg) =>
  `gw_sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${seg}${HTTPS ? "; Secure" : ""}`;

function criarSessao(req, usuario) {
  const token = crypto.randomBytes(32).toString("hex");      
  db.sessoes.push({ id: sha256(token), usuario: usuario.id, expira: Date.now() + SESSAO_MS,
                    ua: String(req.headers["user-agent"] || "").slice(0, 120) });
  salvarDb();
  return token;
}
function sessaoAtual(req) {
  const t = cookies(req).gw_sid;
  if (!t) return null;
  const id = sha256(t);
  const sessao = db.sessoes.find(s => s.id === id);
  if (!sessao || sessao.expira < Date.now()) return null;
  const usuario = db.usuarios.find(u => u.id === sessao.usuario);
  return usuario ? { sessao, usuario } : null;
}
function exigir(req) {
  const a = sessaoAtual(req);
  if (!a) throw new ErroHttp(401, "Sessão expirada. Faça login novamente.");
  return a;
}

/* Limite de tentativas de login: 8 a cada 15 minutos por IP + e-mail */
const tentativas = new Map();
function registroTentativas(req, email) {
  const chave = (req.socket.remoteAddress || "") + "|" + email, agora = Date.now();
  let r = tentativas.get(chave);
  if (!r || r.ate < agora) { r = { n: 0, ate: agora + 15 * 60 * 1000 }; tentativas.set(chave, r); }
  if (r.n >= 8) throw new ErroHttp(429, "Muitas tentativas. Tente novamente em alguns minutos.");
  return { r, chave };
}

/* ---------- Rotas da API ---------- */
const dataOk = s => /^\d{4}-\d{2}-\d{2}$/.test(s || "");
const rotas = {

  "POST /api/cadastro": async (req, res) => {
    const b = await lerCorpo(req, 20_000), email = normEmail(b.email);
    if (!textoOk(b.nome, 60) || !textoOk(b.sobrenome, 60) || !emailOk(email))
      throw new ErroHttp(400, "Preencha nome, sobrenome e um e-mail válido.");
    if (!senhaOk(b.senha)) throw new ErroHttp(400, "A senha precisa ter pelo menos 6 caracteres.");
    if (db.usuarios.some(u => u.email === email)) throw new ErroHttp(409, "Este e-mail já está cadastrado.");
    const u = { id: crypto.randomUUID(), nome: b.nome.trim(), sobrenome: b.sobrenome.trim(), email, senha: await hashSenha(b.senha) };
    if (db.usuarios.some(x => x.email === email)) throw new ErroHttp(409, "Este e-mail já está cadastrado.");
    db.usuarios.push(u);
    const token = criarSessao(req, u);
    enviar(res, 201, { usuario: publico(u) }, { "Set-Cookie": cookieSessao(token, SESSAO_MS / 1000) });
  },

  "POST /api/login": async (req, res) => {
    const b = await lerCorpo(req, 20_000), email = normEmail(b.email);
    const { r, chave } = registroTentativas(req, email);
    const u = db.usuarios.find(x => x.email === email);
    const ok = u && typeof b.senha === "string"
      ? await confereSenha(b.senha, u.senha)
      : (await confereSenha(String(b.senha || ""), await HASH_FALSO), false);
    if (!ok) { r.n++; throw new ErroHttp(401, "E-mail ou senha incorretos."); }
    tentativas.delete(chave);
    const token = criarSessao(req, u);
    enviar(res, 200, { usuario: publico(u) }, { "Set-Cookie": cookieSessao(token, SESSAO_MS / 1000) });
  },

  "POST /api/logout": async (req, res) => {
    const a = sessaoAtual(req);
    if (a) { db.sessoes = db.sessoes.filter(s => s.id !== a.sessao.id); salvarDb(); }
    enviar(res, 200, { ok: true }, { "Set-Cookie": cookieSessao("", 0) });
  },

  "GET /api/me": async (req, res) => {
    enviar(res, 200, { usuario: publico(exigir(req).usuario) });
  },

  "POST /api/me/senha": async (req, res) => {
    const { usuario, sessao } = exigir(req), b = await lerCorpo(req, 20_000);
    if (typeof b.atual !== "string" || !(await confereSenha(b.atual, usuario.senha)))
      throw new ErroHttp(403, "Senha atual incorreta.");
    if (!senhaOk(b.nova)) throw new ErroHttp(400, "A nova senha precisa ter pelo menos 6 caracteres.");
    usuario.senha = await hashSenha(b.nova);
    db.sessoes = db.sessoes.filter(s => s.usuario !== usuario.id || s.id === sessao.id);  // derruba os outros dispositivos
    salvarDb();
    enviar(res, 200, { ok: true });
  },

  "POST /api/me/email": async (req, res) => {
    const { usuario } = exigir(req), b = await lerCorpo(req, 20_000), novo = normEmail(b.novoEmail);
    if (typeof b.senha !== "string" || !(await confereSenha(b.senha, usuario.senha)))
      throw new ErroHttp(403, "Senha incorreta.");
    if (!emailOk(novo)) throw new ErroHttp(400, "Digite um e-mail válido.");
    if (db.usuarios.some(u => u.email === novo && u.id !== usuario.id)) throw new ErroHttp(409, "Este e-mail já está em uso.");
    usuario.email = novo;
    salvarDb();
    enviar(res, 200, { usuario: publico(usuario) });
  },

  "POST /api/me/desconectar-outros": async (req, res) => {
    const { usuario, sessao } = exigir(req);
    const antes = db.sessoes.length;
    db.sessoes = db.sessoes.filter(s => s.usuario !== usuario.id || s.id === sessao.id);
    salvarDb();
    enviar(res, 200, { desconectados: antes - db.sessoes.length });
  },

  /* Os SENSORES enviam por aqui (cabeçalho x-api-key). Aceita 1 leitura ou uma lista de até 1000. */
  "POST /api/leituras": async (req, res) => {
    const enviada = Buffer.from(String(req.headers["x-api-key"] || "")), esperada = Buffer.from(chaveSensores);
    if (enviada.length !== esperada.length || !crypto.timingSafeEqual(enviada, esperada))
      throw new ErroHttp(401, "Chave de sensor inválida.");
    const corpo = await lerCorpo(req), lista = Array.isArray(corpo) ? corpo : [corpo];
    if (!lista.length || lista.length > 1000) throw new ErroHttp(400, "Envie de 1 a 1000 leituras por vez.");
    const agora = Date.now(), novas = [], noLote = new Set(); let ignoradas = 0;
    for (const x of lista) {
      const sensor = String((x && x.sensor) || "").trim();
      const t = Number(x && x.temperatura), u = Number(x && x.umidade);
      let ts = !x || x.momento === undefined ? agora : (typeof x.momento === "number" ? x.momento : Date.parse(x.momento));
      if (!/^[\w.-]{1,40}$/.test(sensor) || !Number.isFinite(t) || t < -50 || t > 100 ||
          !Number.isFinite(u) || u < 0 || u > 100 || !Number.isFinite(ts) || ts > agora + 5 * 60 * 1000)
        throw new ErroHttp(400, "Leitura inválida: " + JSON.stringify(x).slice(0, 120));
      ts = Math.round(ts);
      const k = sensor + "|" + ts;
      if (vistos.has(k) || noLote.has(k)) { ignoradas++; continue; }
      noLote.add(k);
      const p = partes(ts);
      novas.push({ s: sensor, ts, t: Math.round(t * 10) / 10, u: Math.round(u * 10) / 10, d: p.d, h: p.h });
    }
    if (novas.length) {
      fs.appendFileSync(ARQ_LEIT, novas.map(l => JSON.stringify(l)).join("\n") + "\n");
      novas.forEach(indexar);
    }
    enviar(res, 201, { salvas: novas.length, ignoradas });
  },

  /* Cartões do painel: média dos sensores online e contagem */
  "GET /api/resumo": async (req, res) => {
    exigir(req);
    const agora = Date.now(); let on = 0, somaT = 0, somaU = 0; const lista = [];
    for (const [id, s] of sensores) {
      const online = agora - s.ts <= ONLINE_MS;
      if (online) { on++; somaT += s.t; somaU += s.u; }
      lista.push({ id, online, ultimaLeitura: new Date(s.ts).toISOString() });
    }
    lista.sort((a, b) => a.id.localeCompare(b.id));
    enviar(res, 200, {
      temp: on ? Math.round(somaT / on * 10) / 10 : null,
      umid: on ? Math.round(somaU / on) : null,
      sensoresOnline: on, sensoresTotal: sensores.size,
      atualizadoEm: new Date().toISOString(), sensores: lista
    });
  },

  /* Tabela, gráfico e histórico. Parâmetros  */
  "GET /api/leituras": async (req, res, url) => {
    exigir(req);
    const q = url.searchParams, inicio = q.get("inicio"), fim = q.get("fim");
    if ((inicio && !dataOk(inicio)) || (fim && !dataOk(fim))) throw new ErroHttp(400, "Use datas no formato AAAA-MM-DD.");
    const intervalo = [5, 10, 15, 30, 60].includes(Number(q.get("intervalo"))) ? Number(q.get("intervalo")) : 30;
    const limite = Math.min(Math.max(parseInt(q.get("limite")) || 500, 1), 2000);
    const ordem = q.get("ordem") === "asc" ? "asc" : "desc";

    let dias = [...porDia.keys()].sort();
    dias = inicio || fim ? dias.filter(d => (!inicio || d >= inicio) && (!fim || d <= fim)) : dias.slice(-2);

    const grupos = new Map();
    for (const d of dias) for (const l of porDia.get(d)) {
      const mm = Math.floor(Number(l.h.slice(3)) / intervalo) * intervalo;
      const hora = `${l.h.slice(0, 2)}:${String(mm).padStart(2, "0")}`, k = d + " " + hora;
      let g = grupos.get(k);
      if (!g) { g = { data: d, hora, somaT: 0, somaU: 0, n: 0, sens: new Set() }; grupos.set(k, g); }
      g.somaT += l.t; g.somaU += l.u; g.n++; g.sens.add(l.s);
    }
    const todas = [...grupos.values()]
      .map(g => ({ data: g.data, hora: g.hora, t: Math.round(g.somaT / g.n * 10) / 10,
                   u: Math.round(g.somaU / g.n), sensores: g.sens.size, online: true }))
      .sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora));
    if (ordem === "desc") todas.reverse();
    enviar(res, 200, { intervalo, total: todas.length, leituras: todas.slice(0, limite) });
  }
};

/* ---------- Arquivos do site (pasta "public") ---------- */
const MIME = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".png": "image/png", ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".json": "application/json; charset=utf-8" };
function estatico(req, res, pathname) {
  if (pathname === "/") { res.writeHead(302, { Location: "/login.html" }); return res.end(); }
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { res.writeHead(400); return res.end(); }
  if (rel.includes("\0")) { res.writeHead(400); return res.end(); }
  const arq = path.join(DIR_PUBLICO, path.normalize(rel));
  if (!arq.startsWith(DIR_PUBLICO + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(arq, (err, dados) => {
    if (err) { res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" }); return res.end("Página não encontrada."); }
    res.writeHead(200, { "Content-Type": MIME[path.extname(arq).toLowerCase()] || "application/octet-stream",
                         "Cache-Control": "no-cache", "X-Content-Type-Options": "nosniff" });
    res.end(req.method === "HEAD" ? undefined : dados);
  });
}

/* ---------- Servidor ---------- */
const servidor = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");
    if (url.pathname.startsWith("/api/")) {
      if (req.method !== "GET" && !String(req.headers["content-type"] || "").startsWith("application/json"))
        throw new ErroHttp(415, "Envie o corpo como JSON (Content-Type: application/json).");
      const rota = rotas[req.method + " " + url.pathname];
      if (!rota) throw new ErroHttp(404, "Rota não encontrada.");
      return await rota(req, res, url);
    }
    if (req.method !== "GET" && req.method !== "HEAD") { res.writeHead(405); return res.end(); }
    estatico(req, res, url.pathname);
  } catch (e) {
    if (res.headersSent) return res.end();
    if (e instanceof ErroHttp) return enviar(res, e.status, { erro: e.message });
    console.error(e);
    enviar(res, 500, { erro: "Erro interno do servidor." });
  }
});

servidor.listen(PORTA, () => {
  console.log("\n  Green Weather — servidor ligado");
  console.log(`  Site ........ http://localhost:${PORTA}/login.html`);
  console.log(`  Chave dos sensores (cabeçalho x-api-key): ${chaveSensores}`);
  console.log(`  Fuso das leituras: ${FUSO}`);
  if (!fs.existsSync(DIR_PUBLICO)) console.log('  ATENÇÃO: crie a pasta "public" e coloque nela os arquivos do site.');
  console.log("  Para parar: Ctrl + C\n");
});
