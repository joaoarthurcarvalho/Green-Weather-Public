ligar o servidor
node server.js
manter os sensores online (opcional){em outro terminal}
node simulador.js
simular sensores com defeitos
node simulador.js falha
criar mais dias de histórico recente
node simulador.js histórico 7
testar o alarme de sensor offline mais rápido
set ALARME_OFFLINE_MIN=1
node server.js