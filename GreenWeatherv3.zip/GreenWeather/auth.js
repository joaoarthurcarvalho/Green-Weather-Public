
const GW = (() => {
  const K_USUARIOS = "gw_usuarios";
  const K_SESSAO   = "gw_sessao";

  const lerUsuarios = () => { try { return JSON.parse(localStorage.getItem(K_USUARIOS)) || []; } catch { return []; } };
  const salvarUsuarios = l => localStorage.setItem(K_USUARIOS, JSON.stringify(l));
  const normaliza = e => e.trim().toLowerCase();

  async function hash(email, senha){
    const txt = email + ":" + senha;
    if (window.crypto && crypto.subtle){
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(txt));
      return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2,"0")).join("");
    }
    return btoa(unescape(encodeURIComponent(txt)));
  }

  async function cadastrar({nome, sobrenome, email, senha}){
    email = normaliza(email);
    const lista = lerUsuarios();
    if (lista.some(u => u.email === email)) throw new Error("Este e-mail já está cadastrado.");
    lista.push({nome: nome.trim(), sobrenome: sobrenome.trim(), email, senha: await hash(email, senha)});
    salvarUsuarios(lista);
    localStorage.setItem(K_SESSAO, email);
  }

  async function entrar(email, senha){
    email = normaliza(email);
    const u = lerUsuarios().find(x => x.email === email);
    if (!u || u.senha !== await hash(email, senha)) throw new Error("E-mail ou senha incorretos.");
    localStorage.setItem(K_SESSAO, email);
  }

  const sair = () => localStorage.removeItem(K_SESSAO);

  function usuarioAtual(){
    const email = localStorage.getItem(K_SESSAO);
    return email ? lerUsuarios().find(u => u.email === email) || null : null;
  }

  
  function exigirLogin(){ if (!usuarioAtual()) location.replace("login.html"); }
 
  function redirecionarSeLogado(){ if (usuarioAtual()) location.replace("dashboard.html"); }

  
  document.addEventListener("DOMContentLoaded", () => {
    const u = usuarioAtual();
    if (u) document.querySelectorAll("[data-user-name]").forEach(el => el.textContent = `${u.nome} ${u.sobrenome}`);
    const btn = document.getElementById("sair");
    if (btn) btn.addEventListener("click", e => { e.preventDefault(); sair(); location.href = "login.html"; });
  });

    async function atualizarSenha(atual, nova){
    const u = usuarioAtual();
    if (!u || u.senha !== await hash(u.email, atual)) throw new Error("Senha atual incorreta.");
    const lista = lerUsuarios();
    const i = lista.findIndex(x => x.email === u.email);
    lista[i].senha = await hash(u.email, nova);
    salvarUsuarios(lista);
  }

  async function atualizarEmail(senha, novoEmail){
    const u = usuarioAtual();
    novoEmail = normaliza(novoEmail);
    if (!u || u.senha !== await hash(u.email, senha)) throw new Error("Senha incorreta.");
    const lista = lerUsuarios();
    if (lista.some(x => x.email === novoEmail)) throw new Error("Este e-mail já está em uso.");
    const i = lista.findIndex(x => x.email === u.email);
    lista[i].email = novoEmail;
    lista[i].senha = await hash(novoEmail, senha);   // o hash usa o e-mail, então é refeito
    salvarUsuarios(lista);
    localStorage.setItem(K_SESSAO, novoEmail);
  }

return {cadastrar, entrar, sair, usuarioAtual, exigirLogin, redirecionarSeLogado, atualizarSenha, atualizarEmail};
})();
